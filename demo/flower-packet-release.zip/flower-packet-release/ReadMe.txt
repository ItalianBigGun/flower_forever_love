1. 使用
	
	1.1 点击flower.exe开始运行。
	1.2 键盘输入Ctrl+space退出。

2. 设置
	
	2.1 在mp3文件夹中替换对应的文件，修改播放的音乐。
	2.2 在config.json中替换对应的字段，修改显示的字体。

								Create by lizc